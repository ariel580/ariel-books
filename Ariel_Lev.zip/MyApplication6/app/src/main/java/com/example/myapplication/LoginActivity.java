package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class LoginActivity extends AppCompatActivity {
    EditText loginusername,loginpassword;
    Button loginbutton;

    FirebaseAuth auth;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        loginusername = findViewById(R.id.logusername);
        loginpassword = findViewById(R.id.etPassword);
        loginbutton = findViewById(R.id.finish_log_button);
        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!validatePassword() || !validateUsername()){
                    Toast.makeText(LoginActivity.this, "username and/or password not valid", Toast.LENGTH_LONG).show();

                }
                else{
                    checkUser();
                }
            }
        });



    }
    public Boolean validateUsername(){
        String val = loginusername.getText().toString();
        if(val.isEmpty()){
            loginusername.setError("Username cannot be empty");
            return false;
        }
        else{
            loginusername.setError(null);
            return true;
        }
    }
    public Boolean validatePassword(){
        String val = loginpassword.getText().toString();
        if(val.isEmpty()){
            loginpassword.setError("password cannot be empty");
            return false;
        }
        else{
            loginpassword.setError(null);
            return true;
        }
    }
    public void checkUser(){
        String userUsername = loginusername.getText().toString().trim();
        String userPassword = loginpassword.getText().toString().trim();
        auth.signInWithEmailAndPassword(userUsername, userPassword).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                Toast.makeText(LoginActivity.this, "good", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                startActivity(intent);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(LoginActivity.this, "not-good", Toast.LENGTH_SHORT).show();
            }
        });

        /*
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users");
        Query checkUserDatabase = reference.orderByChild("username").equalTo(userUsername);

        checkUserDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    loginusername.setError(null);
                    String passwordFromeDB = snapshot.child(userUsername).child("password").getValue(String.class);
                    if(Objects.equals(passwordFromeDB,userPassword)){
                        loginusername.setError(null);
                        Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                        startActivity(intent);
                    }
                    else{
                        loginpassword.setError("Invalid Credentials");
                        loginpassword.requestFocus();
                    }
                }
                else{
                    loginusername.setError("User does not exist");
                    loginusername.requestFocus();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

         */

    }
}